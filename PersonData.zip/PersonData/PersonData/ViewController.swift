
import UIKit
import CoreData

class ViewController: UIViewController , UITableViewDataSource, UITableViewDelegate{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return people.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let person = people[indexPath.row]
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        cell.textLabel?.text = person.value(forKeyPath: "name") as? String
        return cell
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let person = people[indexPath.row]
        
        let alert = UIAlertController(title: "Update Number",
                                          message: "Update Number",
                                          preferredStyle: .alert)
            
            /*add name textfield*/
            alert.addTextField(configurationHandler: { (textFieldName) in
              textFieldName.placeholder = "name"
              
              textFieldName.text = person.value(forKey: "name") as? String
              
            })
            
            
            
        
            let deleteAction = UIAlertAction(title: "Delete", style: .default) { [unowned self] action in
              
              self.delete(person : person as! Employee)
              self.people.remove(at: (self.people.index(of: person))!)
              tableView.reloadData()
              
            }
            
            /*configure cancel action*/
            let cancelAction = UIAlertAction(title: "Cancel",
                                             style: .default)
            
            /*add all the actions*/
            alert.addAction(cancelAction)
            alert.addAction(deleteAction)
            
            
            present(alert, animated: true)
    }
    
    
    
    
    
    @IBOutlet weak var tableview: UITableView!
    
    var people: [NSManagedObject] = []
    
    @IBAction func addName(_ sender: Any) {
        

        let alert = UIAlertController(title: "New Number", message: "Add a new number", preferredStyle: .alert)
        
        alert.addTextField(configurationHandler: {(textFieldName) in textFieldName.placeholder = "number"})
        
        
        let saveAction = UIAlertAction(title: "Save", style: .default) { [unowned self] action in
        guard  let textField = alert.textFields?.first,
               let nameToSave = textField.text else{
                   return
               }
            
            
            
            self.save(name: nameToSave)
            self.tableview.reloadData()
    }
        let cancelAction = UIAlertAction(title: "Cancel", style: .default)
        alert.addAction(saveAction)
        alert.addAction(cancelAction)
        
        present(alert, animated: true)
    }
    
    
    //insert logic
    func save(name: String){
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else{
            return
        }
        
        let managedContext = appDelegate.persistentContainer.viewContext
        
        let entity = NSEntityDescription.entity(forEntityName: "Employee", in: managedContext)!
        
        let person = NSManagedObject(entity: entity, insertInto: managedContext)

        
        person.setValue(name, forKey: "name")
        

        do{
            try managedContext.save()
            people.append(person)
            tableview.reloadData()
            
        } catch let error as NSError{
            print("Could not save \(error), \(error.userInfo)")
        }
        
        
        
        
        
        
        
        
        
                 
        
        
    }
    
    func fetchAllPersons(){
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
          return
        }
        
        let managedContext = appDelegate.persistentContainer.viewContext
        
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Employee")
        
        do {
          people = try managedContext.fetch(fetchRequest)
        } catch let error as NSError {
          print("Could not fetch. \(error), \(error.userInfo)")
        }
        
      }
    
    
    
    func delete(person : Employee){

        
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
          return
        }
        let managedContext = appDelegate.persistentContainer.viewContext
        
        do {
            managedContext.delete(person)
          
        } catch {
        }
        
        do {
          try managedContext.save()
        } catch {
        }
      }
           func delete(ssn: String) {
             
               guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
                   return
               }
             
             
               let managedContext = appDelegate.persistentContainer.viewContext
             
             
               let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Employee")
             
             
               fetchRequest.predicate = NSPredicate(format: "ssn == %@" ,ssn)
               do {
                 
                 
                   let item = try managedContext.fetch(fetchRequest)
                   for i in item {
                       managedContext.delete(i)
                       try managedContext.save()
                     
                     
                     people.remove(at: (people.index(of: i))!)
                   }
               } catch let error as NSError {
                   print("Could not fetch. \(error), \(error.userInfo)")
               }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        fetchAllPersons()
      }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        tableview.register(UITableViewCell.self, forCellReuseIdentifier: "Cell")
        
    }


}

