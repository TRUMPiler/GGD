//
//  Employee+CoreDataClass.swift
//  PersonData
//
//  Created by bmiit on 5/10/22.
//
//

import Foundation
import CoreData

@objc(Employee)
public class Employee: NSManagedObject {

}
